import java.util.Scanner;

public class lab3extraP10{
  public static void main(String[] args){
    Scanner sin = new Scanner(System.in);
    int[] num = new int[10];
    int countNum=0;
    int count=0;
    
    while (countNum<2){
      System.out.println ("please enter a number between 0 to 9");
      int n = sin.nextInt();
      num[n]++;
      if(num[n]>2){
        countNum++;
      }
    }
    if (count < 2){
      for (int i=0; i<num.length; i++){
      if (num[i]>=2 && num[i]<5){
        System.out.println(i);
      }
      count++;
      }
    }
  }
}

      
        
      
      
    
    
    
                 
import java.util.Scanner;

public class Lab05Task04{
  public static void main(String[] args){
    Scanner sin = new Scanner(System.in);
    System.out.println("Please enter the value of M");
    int M = sin.nextInt();
    System.out.println("Please enter the value of N");
    int N = sin.nextInt();
    int num[][] = new int[M][N];
    Random randomGenerator = new Random();
    int row, column;
    
    for (row = 0; row<M; row++){
      for (column=0; column<N; column++){
        num[row][column] = Math.random() * 
        
    
    
    
    for (row = 0; row<M; row++){
      for (column=0; column<N; column++){
        System.out.print (num[row][column]+"    ");
      }
      System.out.println();
    }
  }
}
          
      
    
                         
                        
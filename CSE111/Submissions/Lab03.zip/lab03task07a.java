public class lab03task07a{
  public static void main (String[] args){
    String s1 = "software";
    String s2 = "programming";
    String s3 = "small";
    System.out.println (s1.compareTo(s2));
    System.out.println (s1.compareTo(s3));
    System.out.println (s3.compareTo(s1));
  }
}
    

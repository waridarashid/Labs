public class Student{
  private String name;
  private String id;
  private String address;
  private double cgpa;
  
  public void setName(String n){
    name = n;
  }
  public void setID(String i){
    id = i;
  }
  public void setAddress(String a){
    address = a;
  }
  public void setCGPA(double c){
    cgpa = c;
  }
  public String getName(){
    return name;
  }
  public String getID(){
    return id;
  }
  public String getAddress(){
    return address;
  }
  public double getCGPA(){
    return cgpa;
  }
}
  

  
    
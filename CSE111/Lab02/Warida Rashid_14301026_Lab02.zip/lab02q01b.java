public class lab02q01b{
  public static void main (String[] args){
    double z;
    z = 5+ Math.sin(80*Math.PI/180);
    System.out.printf("%.4f", z);
  }
}

    
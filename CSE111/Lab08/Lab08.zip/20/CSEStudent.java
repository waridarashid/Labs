public class CSEStudent extends Student{
  public String msg = "I want to transfer to CSE";
  
  public String shout(){
    super.shout();
    return msg;
  }
}

    
    
public class BBAStudent extends Student{
  private String name = "Default BBA Student";
  private String department = "BBA";
  
  public BBAStudent(){
    setName(name);
    setDepartment(department);
  }
  public BBAStudent(String n){
    setName(n);
    setDepartment(department);
    
  }
}
public class SavingsAccount{
  public double annualInterestRate;
  private savingsBalance;
  
  public 
  